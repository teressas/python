import ninja
import pet

timmy = pet.Pet("Timmy","Dog","fetch","woof")    
    
teressa = ninja.Ninja("Teressa", "Sung", "Pasta", "Sushi", timmy)
print(teressa)

teressa.feed()

hero = pet.dog("Lucy","Dog","Roll Over", "Fly")
print(timmy.health)
